sponsorArray = {"Sportsco": None, "Kate's Coffee": None, "Tourism Board": None, "Nate's Kitchen": None, "Fashion Haus": None}

audienceArray = {"Fitness": None, "Hipster": None, "Lifestyle": None, "Fashion": None}

locationArray = {"Cafe": ["cafeBG", "cafeButton"], "Gallery": ["galleryBG", "galleryButton"], "Bedroom": ["bedroomBG", "bedroomButton"], "Nature": ["natureBG", "natureButton"], "City": ["cityBG", "cityButton"], "Studio": ["studioBG", "studioButton"]}

foodArray = {"Coffee": None, "Bagel": None, "Croissant": None, "Sandwich": None, "Ice Cream": None, "Pizza": None, "Burger": None}

outfitArray = {"Shirt": None, "Casual": None, "Dressed Up": None, "Workout": None, "Sneakers": None, "Heels": None, "Hand": None}

itemArray = {"Laptop": None, "Camera": None, "Stationary": None, "Manicure": None, "Sunglasses": None, "Bag": None, "Car": None}

buttonList = list()
modeList = list()

locationList = list()
itemList = list()
hardGoods = ("Gadget", "Camera", "Shades", "Bag", "Shirt", "Casual", "Formal", "Workout", "Sneakers", "Heels")

playerList = list()
sponsorList = list()
audienceList = list()




#"Cafe", "Gallery", "Bedroom", "Nature", "City", "Studio", "Coffee", "Bagel", "Croissant", "Sandwich", "Ice Cream", "Pizza", "Burger", "Shirt", "Casual", "Dressed Up", "Workout", "Sneakers", "Heels", "Hand", "Laptop", "Camera", "Stationary", "Manicure", "Sunglasses", "Bag", "Car"